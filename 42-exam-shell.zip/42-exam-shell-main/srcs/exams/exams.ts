import Two from './02/definition';
import Three from './03/definition';
import Four from './04/definition';
import Five from './05/definition';
import Six from './06/definition';
import oldThree from './old_03/definition';
import { examDefinition } from './interface';

const examList = [
	Two,
	Three,
	Four,
	Five,
	Six,
	oldThree
] as examDefinition[];

export default examList;
