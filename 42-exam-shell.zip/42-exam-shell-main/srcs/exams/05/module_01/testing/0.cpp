#include "ASpell.hpp"

int main(void)
{
    ASpell spell;
    
    return 0;
}
