#include "Warlock.hpp"

int main(void)
{
    Warlock richard("Richard", "Mistress of Magma");
    Warlock bob(richard);

    return 0;
}
