#!/bin/bash

git init -q
git config user.name "Daisy"
git config user.email "daisy@doomguy.com"
